﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace v5
{
    class Student
    {
        internal void AddStudent(string name, string surname, string birthday, string phone)
        {
            throw new NotImplementedException();
        }

        internal void RemoveStudent(string surname)
        {
            throw new NotImplementedException();
        }

        internal void FindStudent(string surname)
        {
            throw new NotImplementedException();
        }

        internal void LoadStudent(string v)
        {
            throw new NotImplementedException();
        }

        internal void Print()
        {
            throw new NotImplementedException();
        }
    }
}
