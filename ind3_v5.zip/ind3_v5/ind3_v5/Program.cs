﻿using ind3_v5;
using System.Collections;
Group group = new Group();
while (true)
{
    Console.WriteLine("-----Меню-----");
    Console.WriteLine("1. Добавить студента");
    Console.WriteLine("2. Удалить студента");
    Console.WriteLine("3. Найти студента по фамилии");
    Console.WriteLine("4. Отобразить всех студентов");
    Console.WriteLine("5. Выход");
    Console.Write("Выберите действие: ");
    int otv = Convert.ToInt32(Console.ReadLine());
    switch (otv) 
    {
        case 1:
            Console.WriteLine("Введите имя: ");
            string name = Console.ReadLine();
            Console.WriteLine("Введите фамилию: ");
            string surname = Console.ReadLine();
            Console.WriteLine("Введите дату рождения(дд.мм.гг): ");
            string birthday = Console.ReadLine();
            Console.WriteLine("Введите номер телефона: ");
            string phone = Console.ReadLine();
            group.AddStudent(name, surname, birthday, phone);
            Console.WriteLine("Вы добавили студента\n");
            break;
        case 2:
            Console.WriteLine("Введите фамилию студента, которого вы хотите удалить: ");
            surname = Console.ReadLine();
            group.RemoveStudent(surname);
            Console.WriteLine("Вы удалили студента\n");
            break;
        case 3:
            Console.WriteLine("Введите фамилию студента, которого вы хотите найти: ");
            surname = Console.ReadLine();
            group.FindStudent(surname);
            break;
        case 4:
            group.LoadStudent("Student.txt");
            group.Display();
            break;
        case 5:
            return;
    }
}