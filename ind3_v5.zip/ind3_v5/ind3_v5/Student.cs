﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;
using System.Threading.Tasks;

namespace ind3_v5
{
    public class Student
    {
        private string name;
        private string surname;
        private string birthday;
        private string phone;
        private ArrayList students = new ArrayList();
        public Student(string n,string s, string b, string p)
        {
            name = n;
            surname = s;
            birthday = b;
            phone = p;
        }
        public void SetSurname(string s)
        {
            surname += s;
        }
        public string GetSurname()
        {
            return surname;
        }
        public string Info()
        {
            return $"{name} {surname}, {birthday}, {phone}";
        }
    }
    public class Group 
    {
        private ArrayList students = new ArrayList();
        public void AddStudent(string n, string s, string b, string p)
        {
            students.Add(new Student(n,s,b,p));
        }
        public void RemoveStudent(string s)
        {
            for (int i = students.Count - 1; i >= 0; i--)
            {
                Student student = (Student)students[i];
                if (student.GetSurname() == s) 
                {
                    students.RemoveAt(i);
                }
            }
        }
        public void FindStudent(string s)
        {
            bool found = false;
            foreach (var student in students)
            {
                Student student1 = (Student)student;
                if (student1.GetSurname() == s)
                {
                    Console.WriteLine(student1.Info());
                    found = true;
                }
            }
            if (!found)
            {
                Console.WriteLine("Не найдено студентов с этой фамилией.");
            }
        }
        public void Display()
        {
            foreach (Student student in students)
            {
                Console.WriteLine(student.Info());
            }
        }
        public void LoadStudent(string file)
        {
            using (var reader = new StreamReader(file))
            {
                string line;
                while ((line = reader.ReadLine()) != null)
                {
                    var parts = line.Split(',');
                    if (parts.Length == 4)
                    {
                        AddStudent(parts[0].Trim(), parts[1].Trim(), parts[2].Trim(), parts[3].Trim());
                    }
                }
            }
        }

    }
}
